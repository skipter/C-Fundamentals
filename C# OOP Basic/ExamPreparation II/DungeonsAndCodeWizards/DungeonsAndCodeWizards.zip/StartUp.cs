﻿using System;

namespace DungeonsAndCodeWizards
{
    public class StartUp
    {
        public static void Main()
        {

        }
    }
}
