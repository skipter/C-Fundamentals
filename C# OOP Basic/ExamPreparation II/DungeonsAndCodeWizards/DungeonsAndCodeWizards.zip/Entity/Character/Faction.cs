﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Entity.Character
{
    public enum Faction
    {
        CSharp = 1,
        Java = 2
    }
}
