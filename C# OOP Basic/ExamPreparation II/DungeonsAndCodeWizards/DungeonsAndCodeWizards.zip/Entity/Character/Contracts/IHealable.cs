﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Entity.Character.Contracts
{
    public interface IHealable
    {
    }
}
