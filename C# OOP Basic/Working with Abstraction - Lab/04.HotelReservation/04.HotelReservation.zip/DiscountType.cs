﻿namespace _04.HotelReservation
{
    public enum DiscountType
    {
        None = 0,
        SecondVisit = 10,
        VIP = 20
    }
}
