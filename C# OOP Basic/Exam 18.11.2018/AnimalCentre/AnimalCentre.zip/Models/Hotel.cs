﻿using AnimalCentre.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalCentre.Models
{
    public class Hotel : IHotel
    {
        private const int capacity = 5;
        private Dictionary<string, IAnimal> animals;

        public Hotel()
        {

        }

        public void Accommodate(IAnimal animal)
        {
            throw new NotImplementedException();
        }

        public void Adopt(string animalName, string owner)
        {
            throw new NotImplementedException();
        }
    }
}
