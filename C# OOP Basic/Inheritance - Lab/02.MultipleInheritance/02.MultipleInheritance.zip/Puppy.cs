﻿using System;

namespace Farm
{
    class Puppy : Dog
    {
        public void Weep()
        {
            Console.WriteLine("weeping…");
        }
    }
}
