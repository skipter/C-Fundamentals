﻿using _01.Vehicles.Models;
using System;

namespace _01.Vehicles
{
    public class StartUp
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
