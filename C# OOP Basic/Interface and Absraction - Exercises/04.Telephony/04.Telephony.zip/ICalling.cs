﻿namespace _04.Telephony
{
    public interface ICalling
    {
        string Calling(string number);
    }
}
