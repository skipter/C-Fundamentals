﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.Telephony
{
    public interface IBrowsing
    {
        string Browsing(string url);
    }
}
