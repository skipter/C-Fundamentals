﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryEliteV1_2.EnumM
{
    public enum State
    {
        inProgress =1,
        Finished = 2
    }
}
