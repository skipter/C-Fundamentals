﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryEliteV1_2.EnumM
{
    public enum Corps
    {
        Airforces = 1,
        Marines = 2
    }
}
