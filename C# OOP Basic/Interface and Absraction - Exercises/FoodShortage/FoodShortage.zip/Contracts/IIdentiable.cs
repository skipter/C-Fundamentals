﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootShortage.Contracts
{
    public interface IIdentiable
    {
        string Id { get; }
    }
}
