﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FootShortage.Contracts
{
    public interface IAge
    {
        int Age { get; }
    }
}
