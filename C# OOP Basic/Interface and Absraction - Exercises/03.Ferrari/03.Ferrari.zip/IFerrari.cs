﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Ferrari
{
    public interface IFerrari
    {
        string Driver { get; }
    }
}
