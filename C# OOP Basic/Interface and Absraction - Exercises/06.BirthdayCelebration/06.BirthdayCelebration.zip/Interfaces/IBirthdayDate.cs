﻿
public interface IBirthdayDate
{
    string Birthdate { get; }
}

