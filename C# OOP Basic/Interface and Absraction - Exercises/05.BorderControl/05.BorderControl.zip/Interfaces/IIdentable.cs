﻿public interface IIdentable
{
    string Id { get; }
}

