﻿namespace _05.MordorsCruelPlan
{
    public class Mushrooms : Food
    {
        public Mushrooms() : base(-10)
        {
        }
    }
}
