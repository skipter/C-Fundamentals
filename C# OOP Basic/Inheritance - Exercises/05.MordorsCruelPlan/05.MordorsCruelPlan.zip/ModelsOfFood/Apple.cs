﻿namespace _05.MordorsCruelPlan
{
    public class Apple : Food
    {
        public Apple() : base(1)
        {
        }
    }
}
