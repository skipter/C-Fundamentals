﻿namespace _05.MordorsCruelPlan
{
    public class Cram : Food
    {
        public Cram() : base(2)
        {
        }
    }
}
