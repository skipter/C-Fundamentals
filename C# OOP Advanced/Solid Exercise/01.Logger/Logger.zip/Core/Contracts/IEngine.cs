﻿namespace _01.Logger.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
