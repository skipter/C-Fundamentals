﻿namespace _01.Logger.Layouts.Contracts
{
    public interface ILayouts
    {
        string Format { get; }
    }
}
