﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MySpecialApp.Models.Contracts
{
    public interface IReader
    {
        string Read();
    }
}
