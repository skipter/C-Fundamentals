﻿namespace MyCrazyApp.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
