﻿namespace _01.ListyIterator
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class ListyIterator<T>
    {
        private List<T> collection;
        private int index;

        public ListyIterator(params T[] collection)
        {
            this.index = 0;
            this.collection = new List<T>(collection);
        }

        public bool Move()
        {
            if (!HasNext())
            {
                return false;
            }
            this.index++;
            return true;
        }

        public bool HasNext()
        {
            bool hasNextElement = index < this.collection.Count - 1;
            return hasNextElement;
        }

        public void Print()
        {
            if (!this.collection.Any())
            {
                throw new InvalidOperationException("Invalid Operation!");
            }
            Console.WriteLine(this.collection[index]);
        }
    }
}
