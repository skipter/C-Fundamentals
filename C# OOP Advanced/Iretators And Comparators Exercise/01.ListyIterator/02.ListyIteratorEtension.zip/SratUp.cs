﻿namespace _01.ListyIterator
{
    public class SratUp
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
