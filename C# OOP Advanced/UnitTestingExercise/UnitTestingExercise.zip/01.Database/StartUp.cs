﻿using System;

namespace _01.Database
{
    public class StartUp
    {
        public static void Main()
        {
            
        }
    }
}
