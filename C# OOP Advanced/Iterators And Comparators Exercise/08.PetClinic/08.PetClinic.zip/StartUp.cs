﻿namespace _08.PetClinic
{
    using _08.PetClinic.Core;

    public class StartUp
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
