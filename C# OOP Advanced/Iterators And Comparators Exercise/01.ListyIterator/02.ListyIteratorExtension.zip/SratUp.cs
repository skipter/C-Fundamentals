﻿namespace _01.ListyIterator
{
    public class SratUp
    {
        public static void Main()
        {
            //75/100
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
